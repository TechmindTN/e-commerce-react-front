"use strict";
exports.id = 3247;
exports.ids = [3247];
exports.modules = {

/***/ 1440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useEcomerce)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3328);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5515);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_cookie__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5097);





function useEcomerce() {
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: cartItemsOnCookie  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [cookies, setCookie] = (0,react_cookie__WEBPACK_IMPORTED_MODULE_2__.useCookies)([
        'cart'
    ]);
    const { 0: products , 1: setProducts  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    return {
        loading,
        cartItemsOnCookie,
        products,
        getProducts: async (payload, group = '')=>{
            setLoading(true);
            if (payload && payload.length > 0) {
                let queries = '';
                payload.forEach((item)=>{
                    if (queries === '') {
                        queries = `id_in=${item.id}`;
                    } else {
                        queries = queries + `&id_in=${item.id}`;
                    }
                });
                const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_1__/* ["default"].getProductsByIds */ .Z.getProductsByIds(queries);
                if (responseData && responseData.length > 0) {
                    if (group === 'cart') {
                        let cartItems = responseData;
                        payload.forEach((item)=>{
                            let existItem = cartItems.find((val)=>val.id === item.id
                            );
                            if (existItem) {
                                existItem.quantity = item.quantity;
                            }
                        });
                        setProducts(cartItems);
                    } else {
                        setProducts(responseData);
                    }
                    setTimeout((function() {
                        setLoading(false);
                    }).bind(this), 250);
                }
            } else {
                setLoading(false);
                setProducts([]);
            }
        },
        increaseQty: (payload, currentCart)=>{
            let cart = [];
            if (currentCart) {
                cart = currentCart;
                const existItem = cart.find((item)=>item.id === payload.id
                );
                if (existItem) {
                    existItem.quantity = existItem.quantity + 1;
                }
                setCookie('cart', cart, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCartItems */ .w0)(cart));
            }
            return cart;
        },
        decreaseQty: (payload, currentCart)=>{
            let cart = [];
            if (currentCart) {
                cart = currentCart;
                const existItem = cart.find((item)=>item.id === payload.id
                );
                if (existItem) {
                    if (existItem.quantity > 1) {
                        existItem.quantity = existItem.quantity - 1;
                    }
                }
                setCookie('cart', cart, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCartItems */ .w0)(cart));
            }
            return cart;
        },
        addItem: (newItem, items, group)=>{
            let newItems = [];
            if (items) {
                newItems = items;
                const existItem = items.find((item)=>item.id === newItem.id
                );
                if (existItem) {
                    if (group === 'cart') {
                        existItem.quantity += newItem.quantity;
                    }
                } else {
                    newItems.push(newItem);
                }
            } else {
                newItems.push(newItem);
            }
            if (group === 'cart') {
                setCookie('cart', newItems, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCartItems */ .w0)(newItems));
            }
            if (group === 'wishlist') {
                setCookie('wishlist', newItems, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setWishlistTtems */ .hT)(newItems));
            }
            if (group === 'compare') {
                setCookie('compare', newItems, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCompareItems */ .Sk)(newItems));
            }
            return newItems;
        },
        removeItem: (selectedItem, items, group)=>{
            let currentItems = items;
            if (currentItems.length > 0) {
                const index = currentItems.findIndex((item)=>item.id === selectedItem.id
                );
                currentItems.splice(index, 1);
            }
            if (group === 'cart') {
                setCookie('cart', currentItems, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCartItems */ .w0)(currentItems));
            }
            if (group === 'wishlist') {
                setCookie('wishlist', currentItems, {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setWishlistTtems */ .hT)(currentItems));
            }
            if (group === 'compare') {
                setCookie('compare', currentItems, {
                    path: '/'
                });
            }
        },
        removeItems: (group)=>{
            if (group === 'wishlist') {
                setCookie('wishlist', [], {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setWishlistTtems */ .hT)([]));
            }
            if (group === 'compare') {
                setCookie('compare', [], {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCompareItems */ .Sk)([]));
            }
            if (group === 'cart') {
                setCookie('cart', [], {
                    path: '/'
                });
                dispatch((0,_store_ecomerce_action__WEBPACK_IMPORTED_MODULE_4__/* .setCartItems */ .w0)([]));
            }
        }
    };
};


/***/ }),

/***/ 6922:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useProduct)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9346);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8833);
/* harmony import */ var _utilities_product_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8798);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);






function getImageURL(source, size) {
    let image, imageURL;
    if (source) {
        if (size && size === 'large') {
            if (source.formats.large) {
                image = source.formats.large.url;
            } else {
                image = source.url;
            }
        } else if (size && size === 'medium') {
            if (source.formats.medium) {
                image = source.formats.medium.url;
            } else {
                image = source.url;
            }
        } else if (size && size === 'thumbnail') {
            if (source.formats.thumbnail) {
                image = source.formats.source.url;
            } else {
                image = source.url;
            }
        } else if (size && size === 'small') {
            if (source.formats.small !== undefined) {
                image = source.formats.small.url;
            } else {
                image = source.url;
            }
        } else {
            image = source.url;
        }
        imageURL = `${_repositories_Repository__WEBPACK_IMPORTED_MODULE_3__/* .baseUrl */ .FH}${image}`;
    } else {
        imageURL = `/static/img/undefined-product-thumbnail.jpg`;
    }
    return imageURL;
}
function useProduct() {
    return {
        thumbnailImage: (payload)=>{
            if (payload) {
                if (payload.thumbnail) {
                    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_lazyload__WEBPACK_IMPORTED_MODULE_2___default()), {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                src: getImageURL(payload.thumbnail),
                                alt: getImageURL(payload.thumbnail)
                            })
                        })
                    }));
                }
            }
        },
        price: (payload)=>{
            let view;
            if (payload.sale_price) {
                view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "ps-product__price sale",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            children: "$"
                        }),
                        (0,_utilities_product_helper__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(payload.sale_price),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                            className: "ml-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                    children: "$"
                                }),
                                (0,_utilities_product_helper__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(payload.price)
                            ]
                        })
                    ]
                });
            } else {
                view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    className: "ps-product__price",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            children: "$"
                        }),
                        (0,_utilities_product_helper__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(payload.price)
                    ]
                });
            }
            return view;
        },
        badges: (payload)=>{
            let view = null;
            if (payload.badges && payload.badges.length > 0) {
                const items = payload.badges.map((item)=>{
                    if (item.value === 'hot') {
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "ps-product__badge hot",
                            children: "Hot"
                        }, item.id));
                    }
                    if (item.value === 'new') {
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "ps-product__badge new",
                            children: "New"
                        }, item.id));
                    }
                    if (item.value === 'sale') {
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            className: "ps-product__badge sale",
                            children: "Sale"
                        }, item.id));
                    }
                });
                view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "ps-product__badges",
                    children: items
                });
            }
            return view;
        },
        badge: (payload)=>{
            let view;
            if (payload.badge && payload.badge !== null) {
                view = payload.badge.map((badge)=>{
                    if (badge.type === 'sale') {
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "ps-product__badge",
                            children: badge.value
                        }));
                    } else if (badge.type === 'outStock') {
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "ps-product__badge out-stock",
                            children: badge.value
                        }));
                    } else {
                        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "ps-product__badge hot",
                            children: badge.value
                        }));
                    }
                });
            }
            if (payload.sale_price) {
                const discountPercent = ((payload.price - payload.sale_price) / payload.sale_price * 100).toFixed(0);
                return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "ps-product__badge",
                    children: [
                        "-",
                        discountPercent,
                        "%"
                    ]
                }));
            }
            return view;
        },
        brand: (payload)=>{
            let view;
            if (payload.brands && payload.brands.length > 0) {
                view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_5__["default"], {
                    href: "/shop",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        className: "text-capitalize",
                        children: payload.brands[0].name
                    })
                });
            } else {
                view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_5__["default"], {
                    href: "/shop",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        className: "text-capitalize",
                        children: "No Brand"
                    })
                });
            }
            return view;
        },
        title: (payload)=>{
            let view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_5__["default"], {
                href: "/product/[pid]",
                as: `/product/${payload.id}`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    className: "ps-product__title",
                    children: payload.title
                })
            });
            return view;
        }
    };
};


/***/ }),

/***/ 3328:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8833);

class ProductRepository {
    async getRecords(params) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/products?${(0,_Repository__WEBPACK_IMPORTED_MODULE_0__/* .serializeQuery */ .Y$)(params)}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProducts(params) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/products?${(0,_Repository__WEBPACK_IMPORTED_MODULE_0__/* .serializeQuery */ .Y$)(params)}`).then((response)=>{
            if (response.data && response.data.length > 0) {
                return response.data;
            } else {
                return null;
            }
        }).catch((error)=>{
            console.log(JSON.stringify(error));
            return null;
        });
        return reponse;
    }
    async getBrands() {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/brands`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductCategories() {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/product-categories`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getTotalRecords() {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/products/count`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductsById(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/products/${payload}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductsByCategory(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/product-categories?slug=${payload}`).then((response)=>{
            if (response.data) {
                if (response.data.length > 0) {
                    return response.data[0];
                }
            } else {
                return null;
            }
        }).catch(()=>{
            return null;
        });
        return reponse;
    }
    async getProductsByBrand(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/brands?slug=${payload}`).then((response)=>{
            if (response.data) {
                if (response.data.length > 0) {
                    return response.data[0];
                }
            } else {
                return null;
            }
        }).catch(()=>{
            return null;
        });
        return reponse;
    }
    async getProductsByBrands(payload) {
        let query = '';
        payload.forEach((item)=>{
            if (query === '') {
                query = `id_in=${item}`;
            } else {
                query = query + `&id_in=${item}`;
            }
        });
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/brands?${query}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductsByBrands(payload) {
        let query = '';
        payload.forEach((item)=>{
            if (query === '') {
                query = `id_in=${item}`;
            } else {
                query = query + `&id_in=${item}`;
            }
        });
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/brands?${query}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductsByPriceRange(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/products?${(0,_Repository__WEBPACK_IMPORTED_MODULE_0__/* .serializeQuery */ .Y$)(payload)}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductsByIds(payload) {
        const endPoint = `${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/products?${payload}`;
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(endPoint).then((response)=>{
            if (response.data && response.data.length > 0) {
                return response.data;
            } else {
                return null;
            }
        }).catch((error)=>{
            console.log(JSON.stringify(error));
            return null;
        });
        return reponse;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new ProductRepository());


/***/ }),

/***/ 8833:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$Y": () => (/* binding */ basePostUrl),
/* harmony export */   "r": () => (/* binding */ baseStoreURL),
/* harmony export */   "FH": () => (/* binding */ baseUrl),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Y$": () => (/* binding */ serializeQuery)
/* harmony export */ });
/* unused harmony export customHeaders */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const baseDomain = 'https://beta.apinouthemes.com'; // API for products
const basePostUrl = 'https://beta.apinouthemes.com'; // API for post
const baseStoreURL = 'https://beta.apinouthemes.com'; // API for vendor(store)
const customHeaders = {
    Accept: 'application/json'
};
const baseUrl = `${baseDomain}`;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axios__WEBPACK_IMPORTED_MODULE_0___default().create({
    baseUrl,
    headers: customHeaders
}));
const serializeQuery = (query)=>{
    return Object.keys(query).map((key)=>`${encodeURIComponent(key)}=${encodeURIComponent(query[key])}`
    ).join('&');
};


/***/ }),

/***/ 2224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hp": () => (/* binding */ actionTypes),
/* harmony export */   "x4": () => (/* binding */ login),
/* harmony export */   "he": () => (/* binding */ loginSuccess),
/* harmony export */   "ni": () => (/* binding */ logOut),
/* harmony export */   "Gd": () => (/* binding */ logOutSuccess)
/* harmony export */ });
/* unused harmony export check_authorization */
const actionTypes = {
    LOGIN_REQUEST: 'LOGIN_REQUEST',
    LOGIN_SUCCESS: 'LOGIN_SUCCESS',
    LOGOUT: 'LOGOUT',
    LOGOUT_SUCCESS: 'LOGOUT_SUCCESS',
    CHECK_AUTHORIZATION: 'CHECK_AUTHORIZATION'
};
function login() {
    return {
        type: actionTypes.LOGIN_REQUEST
    };
}
function loginSuccess() {
    return {
        type: actionTypes.LOGIN_SUCCESS
    };
}
function logOut() {
    return {
        type: actionTypes.LOGOUT
    };
}
function logOutSuccess() {
    return {
        type: actionTypes.LOGOUT_SUCCESS
    };
}
function check_authorization() {
    return {
        type: actionTypes.CHECK_AUTHORIZATION
    };
}


/***/ }),

/***/ 5097:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hp": () => (/* binding */ actionTypes),
/* harmony export */   "hT": () => (/* binding */ setWishlistTtems),
/* harmony export */   "sC": () => (/* binding */ setWishlistTtemsSuccess),
/* harmony export */   "w0": () => (/* binding */ setCartItems),
/* harmony export */   "_r": () => (/* binding */ setCartItemsSuccess),
/* harmony export */   "Sk": () => (/* binding */ setCompareItems),
/* harmony export */   "bD": () => (/* binding */ setCompareItemsSuccess)
/* harmony export */ });
const actionTypes = {
    // new
    SET_WISHLIST_ITEMS: 'SET_WISHLIST_ITEMS',
    SET_WISHLIST_ITEMS_SUCCESS: 'SET_WISHLIST_ITEMS_SUCCESS',
    SET_CART_ITEMS: 'SET_CART_ITEMS',
    SET_CART_ITEMS_SUCCESS: 'SET_CART_ITEMS_SUCCESS',
    SET_COMPARE_ITEMS: 'SET_COMPARE_ITEMS',
    SET_COMPARE_ITEMS_SUCCESS: 'SET_COMPARE_ITEMS_SUCCESS'
};
// new
function setWishlistTtems(payload) {
    return {
        type: actionTypes.SET_WISHLIST_ITEMS,
        payload
    };
}
function setWishlistTtemsSuccess(payload) {
    return {
        type: actionTypes.SET_WISHLIST_ITEMS_SUCCESS,
        payload
    };
}
function setCartItems(payload) {
    return {
        type: actionTypes.SET_CART_ITEMS,
        payload
    };
}
function setCartItemsSuccess(payload) {
    return {
        type: actionTypes.SET_CART_ITEMS_SUCCESS,
        payload
    };
}
function setCompareItems(payload) {
    return {
        type: actionTypes.SET_COMPARE_ITEMS,
        payload
    };
}
function setCompareItemsSuccess(payload) {
    return {
        type: actionTypes.SET_COMPARE_ITEMS_SUCCESS,
        payload
    };
}


/***/ }),

/***/ 5245:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "fu": () => (/* binding */ calculateAmount)
/* harmony export */ });
/* unused harmony exports getCartItemsFromCookies, updateCartToCookies, addItemToCartHelper, increaseQtyCartItemHelper, decreaseQtyCartItemHelper, removeCartItemHelper, calculateCartQuantity, caculateArrayQuantity */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6734);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3328);
/*
 * React template helpers
 * Author: Nouthemes
 * Developed: diaryforlife
 * */ 


function getCartItemsFromCookies() {
    const cartItems = cookies.get('cart');
    if (cartItems) {
        return JSON.parse(cartItems);
    } else {
        return null;
    }
}
function updateCartToCookies(payload) {
    cookies.set('cart', payload, {
        path: '/',
        expires: 24 * 7
    });
}
function addItemToCartHelper(product) {
    let cart;
    let cookieCart = getCartItemsFromCookies();
    if (cookieCart) {
        cart = cookieCart;
        const existItem = cart.items.find((item)=>item.id === product.id
        );
        if (existItem) {
            existItem.quantity += product.quantity;
        } else {
            /* if (!product.quantity) {
                product.quantity = 1;
            }*/ cart.items.push(product);
        }
    } else {
        cart = {
            items: []
        };
        cart.items.push(product);
    }
    updateCartToCookies(cart);
    return cart;
}
function increaseQtyCartItemHelper(product) {
    let cart;
    let cookieCart = getCartItemsFromCookies();
    if (cookieCart) {
        cart = cookieCart;
        const selectedItem = cart.items.find((item)=>item.id === product.id
        );
        if (selectedItem) {
            selectedItem.quantity = selectedItem.quantity + 1;
        }
        updateCartToCookies(cart);
        return cart;
    }
}
function decreaseQtyCartItemHelper(product) {
    let cart;
    let cookieCart = getCartItemsFromCookies();
    if (cookieCart) {
        cart = cookieCart;
        const selectedItem = cart.items.find((item)=>item.id === product.id
        );
        if (selectedItem) {
            selectedItem.quantity = selectedItem.quantity - 1;
        }
        updateCartToCookies(cart);
        return cart;
    }
}
function removeCartItemHelper(product) {
    let cart;
    let cookieCart = getCartItemsFromCookies();
    if (cookieCart) {
        cart = cookieCart;
        const index = cart.items.findIndex((item)=>item.id === product.id
        );
        cart.items.splice(index, 1);
        updateCartToCookies(cart);
        return cart;
    }
}
// new
function calculateAmount(obj) {
    return Object.values(obj).reduce((acc, { quantity , price  })=>acc + quantity * price
    , 0).toFixed(2);
}
function calculateCartQuantity(obj) {
    return Object.values(obj).reduce((acc, { quantity  })=>acc + quantity
    , 0);
}
function caculateArrayQuantity(obj) {
    return Object.values(obj).reduce((acc)=>acc + 1
    , 0);
}


/***/ }),

/***/ 8798:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "xG": () => (/* binding */ formatCurrency),
/* harmony export */   "QR": () => (/* binding */ getItemBySlug),
/* harmony export */   "sj": () => (/* binding */ convertSlugsQueryString),
/* harmony export */   "cg": () => (/* binding */ StrapiProductPriceExpanded)
/* harmony export */ });
/* unused harmony exports getColletionBySlug, StrapiProductThumbnail */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9346);
/* harmony import */ var react_lazyload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_lazyload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8833);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);





function formatCurrency(num) {
    if (num !== undefined) {
        return parseFloat(num).toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
    } else {}
}
function getColletionBySlug(collections, slug) {
    if (collections.length > 0) {
        const result = collections.find((item)=>item.slug === slug.toString()
        );
        if (result !== undefined) {
            return result.products;
        } else {
            return [];
        }
    } else {
        return [];
    }
}
function getItemBySlug(banners, slug) {
    if (banners.length > 0) {
        const banner = banners.find((item)=>item.slug === slug.toString()
        );
        if (banner !== undefined) {
            return banner;
        } else {
            return null;
        }
    } else {
        return null;
    }
}
function convertSlugsQueryString(payload) {
    let query = '';
    if (payload.length > 0) {
        payload.forEach((item)=>{
            if (query === '') {
                query = `slug_in=${item}`;
            } else {
                query = query + `&slug_in=${item}`;
            }
        });
    }
    return query;
}
function StrapiProductPriceExpanded(product) {
    let view;
    if (product.is_sale === true) {
        view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            className: "ps-product__price sale",
            children: [
                "$",
                formatCurrency(product.price),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                    className: "ml-2",
                    children: [
                        "$",
                        formatCurrency(product.sale_price)
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("small", {
                    children: "18% off"
                })
            ]
        });
    } else {
        view = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
            className: "ps-product__price",
            children: [
                "$",
                formatCurrency(product.price)
            ]
        });
    }
    return view;
}
function StrapiProductThumbnail(product) {
    let view;
    if (product.thumbnail) {
        view = /*#__PURE__*/ _jsx(Link, {
            href: "/product/[pid]",
            as: `/product/${product.id}`,
            children: /*#__PURE__*/ _jsx("a", {
                children: /*#__PURE__*/ _jsx(LazyLoad, {
                    children: /*#__PURE__*/ _jsx("img", {
                        src: `${baseUrl}${product.thumbnail.url}`,
                        alt: product.title
                    })
                })
            })
        });
    } else {
        view = /*#__PURE__*/ _jsx(Link, {
            href: "/product/[pid]",
            as: `/product/${product.id}`,
            children: /*#__PURE__*/ _jsx("a", {
                children: /*#__PURE__*/ _jsx(LazyLoad, {
                    children: /*#__PURE__*/ _jsx("img", {
                        src: "/static/img/not-found.jpg",
                        alt: "martfury"
                    })
                })
            })
        });
    }
    return view;
}


/***/ }),

/***/ 8398:
/***/ ((module) => {

module.exports = JSON.parse('{"A":{"u":[{"text":"Home","url":"/","extraClass":"menu-item-has-children","subClass":"sub-menu","subMenu":[{"text":"Marketplace Full Width","url":"/"},{"text":"Home Auto Parts","url":"/home/auto-part"},{"text":"Home Technology","url":"/home/technology"},{"text":"Home Organic","url":"/home/organic"},{"text":"Home Marketplace V1","url":"/home/market-place"},{"text":"Home Marketplace V2","url":"/home/market-place-2"},{"text":"Home Marketplace V3","url":"/home/market-place-3"},{"text":"Home Marketplace V4","url":"/home/market-place-4"},{"text":"Home Electronic","url":"/home/electronic"},{"text":"Home Furniture","url":"/home/furniture"}]},{"text":"Shop","url":"/shop","extraClass":"menu-item-has-children has-mega-menu","subClass":"sub-menu","mega":"true","megaContent":[{"heading":"Catalog Pages","megaItems":[{"text":"Shop Default","url":"/shop"},{"text":"Shop Fullwidth","url":"/shop/shop-fullwidth"},{"text":"Shop Categories","url":"/shop/shop-categories"},{"text":"Shop Sidebar","url":"/shop/shop-sidebar"},{"text":"Shop Without Banner","url":"/shop/shop-sidebar-without-banner"},{"text":"Shop Carousel","url":"/shop/shop-carousel"}]},{"heading":"Product Layout","megaItems":[{"text":"Default","url":"/product/3"},{"text":"Extended","url":"/product/extended/7"},{"text":"Full Content","url":"/product/full-content/7"},{"text":"Boxed","url":"/product/boxed/7"},{"text":"Sidebar","url":"/product/sidebar/7"}]},{"heading":"Product Types","megaItems":[{"text":"Simple","url":"/product/3"},{"text":"Image swatches","url":"/product/image-swatches/11"},{"text":"Countdown","url":"/product/countdown/10"},{"text":"Affiliate","url":"/product/affiliate/7"},{"text":"On sale","url":"/product/on-sale/7"},{"text":"Grouped","url":"/product/groupped/22"},{"text":"Out Of Stock","url":"/product/out-of-stock/7"}]},{"heading":"Ecomerce Pages","megaItems":[{"text":"Shopping Cart","url":"/account/shopping-cart"},{"text":"Checkout","url":"/account/checkout"},{"text":"Whishlist","url":"/account/wishlist"},{"text":"Compare","url":"/account/compare"},{"text":"Order Tracking","url":"/account/order-tracking"},{"text":"My Account","url":"/account/login"},{"text":"Login / Register","url":"/account/login"}]}]},{"text":"Pages","url":"","extraClass":"menu-item-has-children has-mega-menu","subClass":"sub-menu","mega":"true","megaContent":[{"heading":"Basic Page","megaItems":[{"text":"About Us","url":"/page/about-us"},{"text":"Contact","url":"/page/contact-us"},{"text":"Faqs","url":"/page/faqs"},{"text":"404 Page","url":"/page/page-404"}]},{"heading":"Vendor Pages","megaItems":[{"text":"Become a Vendor","url":"/vendor/become-a-vendor"},{"text":"Vendor Store","url":"/vendor/vendor-store"},{"text":"Store List","url":"/stores"}]}]},{"text":"Blogs","url":"/blog","current":"shop","extraClass":"menu-item-has-children has-mega-menu","subClass":"sub-menu","mega":"true","megaContent":[{"heading":"Blog Layout","megaItems":[{"text":"Grid","url":"/blog"},{"text":"Small Thumb","url":"/blog/blog-small-thumbnail"},{"text":"Left Sidebar","url":"/blog/blog-left-sidebar"},{"text":"Right Sidebar","url":"/blog/blog-right-sidebar"}]},{"heading":"Single Blog","megaItems":[{"text":"Single 1","url":"/post/default"},{"text":"Single 2","url":"/post/detail-2"},{"text":"Single 3","url":"/post/detail-3"}]}]}]},"a":[{"icon":"icon-star","text":"Hot Promotions","url":"/shop"},{"icon":"icon-laundry","text":"Consumer Electronic","url":"/shop","extraClass":"menu-item-has-children has-mega-menu","subClass":"sub-menu","mega":true,"megaContent":[{"heading":"Electronic","megaItems":[{"text":"Home Audio & Theathers","url":"/shop"},{"text":"TV & Videos","url":"/shop"},{"text":"Camera, Photos & Videos","url":"/shop"},{"text":"Cellphones & Accessories","url":"/shop"},{"text":"Headphones","url":"/shop"},{"text":"Videosgames","url":"/shop"},{"text":"Wireless Speakers","url":"/shop"},{"text":"Office Electronic","url":"/shop"}]},{"heading":"Accessories & Parts","megaItems":[{"text":"Digital Cables","url":"/shop"},{"text":"Audio & Video Cables","url":"/shop"},{"text":"Batteries","url":"/shop"}]}]},{"icon":"icon-shirt","text":"Clothing & Apparel","url":"/shop"},{"icon":"icon-lampshade","text":"Home, Garden & Kitchen","url":"/shop"},{"icon":"icon-heart-pulse","text":"Health & Beauty","url":"/shop"},{"icon":"icon-diamond2","text":"Yewelry & Watches","url":"/shop"},{"icon":"icon-desktop","text":"Computer & Technology","url":"/shop","extraClass":"menu-item-has-children has-mega-menu","subClass":"sub-menu","megaContent":[{"heading":"Computer & Technologies","megaItems":[{"text":"Computer & Tablets","url":"/shop"},{"text":"Laptop","url":"/shop"},{"text":"Monitors","url":"/shop"},{"text":"Networking","url":"/shop"},{"text":"Drive & Storages","url":"/shop"},{"text":"Computer Components","url":"/shop"},{"text":"Security & Protection","url":"/shop"},{"text":"Gaming Laptop","url":"/shop"},{"text":"Accessories","url":"/shop"}]}]},{"icon":"icon-baby-bottle","text":"Babies & Moms","url":"/shop"},{"icon":"icon-baseball","text":"Sport & Outdoor","url":"/shop"},{"icon":"icon-smartphone","text":"Phones & Accessories","url":"/shop"},{"icon":"icon-book2","text":"Books & Office","url":"/shop"},{"icon":"icon-car-siren","text":"Cars & Motocycles","url":"/shop"},{"icon":"icon-wrench","text":"Home Improments","url":"/shop"},{"icon":"icon-tag","text":"Vouchers & Services","url":"/shop"}]}');

/***/ })

};
;