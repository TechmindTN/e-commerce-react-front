"use strict";
exports.id = 4930;
exports.ids = [4930];
exports.modules = {

/***/ 4930:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_elements_products_ProductDealOfDay__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4258);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1675);
/* harmony import */ var _components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7706);
/* harmony import */ var _utilities_strapi_fetch_data_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7436);
/* harmony import */ var _utilities_carousel_helpers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3780);
/* harmony import */ var _components_elements_CountDownSimple__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(386);
/* harmony import */ var _hooks_useGetProducts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2933);











const MarketPlaceDealOfDay = ({ collectionSlug  })=>{
    const { productItems , loading , getProductsByCollection  } = (0,_hooks_useGetProducts__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getProductsByCollection(collectionSlug);
    }, [
        collectionSlug
    ]);
    // Views
    let productItemsView;
    if (!loading) {
        if (productItems && productItems.length > 0) {
            const slideItems = productItems.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_products_ProductDealOfDay__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    product: item
                }, item.id)
            );
            productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                ..._utilities_carousel_helpers__WEBPACK_IMPORTED_MODULE_7__/* .carouselStandard */ .aL,
                className: "ps-carousel outside",
                children: slideItems
            });
        } else {
            productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                children: "No product(s) found."
            });
        }
    } else {
        const skeletons = (0,_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_10__/* .generateTempArray */ .Z)(6).map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "col-xl-2 col-lg-3 col-sm-3 col-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            }, item)
        );
        productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "row",
            children: skeletons
        });
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        className: "ps-deal-of-day",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "ps-container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "ps-section__header",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "ps-block--countdown-deal",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "ps-block__left",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
                                        children: "Deal of the day"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                                    className: "ps-block__right",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("figure", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("figcaption", {
                                                children: "End in:"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_CountDownSimple__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                timeTillDate: "12 31 2021, 6:00 am",
                                                timeFormat: "MM DD YYYY, h:mm a"
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: "/shop",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: "View all"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "ps-section__content",
                    children: productItemsView
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MarketPlaceDealOfDay);


/***/ })

};
;