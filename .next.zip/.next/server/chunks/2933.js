"use strict";
exports.id = 2933;
exports.ids = [2933];
exports.modules = {

/***/ 2933:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetProducts)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utilities_strapi_fetch_data_helpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7436);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3328);



function useGetProducts() {
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const { 0: productItems , 1: setProductItems  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const { 0: product , 1: setProduct  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    return {
        loading,
        productItems,
        product,
        setProductItems: (payload)=>{
            setProductItems(payload);
        },
        setLoading: (payload)=>{
            setLoading(payload);
        },
        getProductsByCollection: async (payload)=>{
            setLoading(true);
            const responseData = await (0,_utilities_strapi_fetch_data_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getProductsByCollectionHelper */ .l)(payload);
            if (responseData) {
                setProductItems(responseData.items);
                setTimeout((function() {
                    setLoading(false);
                }).bind(this), 250);
            }
        },
        getProductsByCategory: async (payload)=>{
            setLoading(true);
            const responseData = await (0,_utilities_strapi_fetch_data_helpers__WEBPACK_IMPORTED_MODULE_1__/* .getProductsByCategoriesHelper */ .b)(payload);
            if (responseData) {
                setProductItems(responseData.items);
                setTimeout((function() {
                    setLoading(false);
                }).bind(this), 250);
            }
        },
        getProducts: async (payload)=>{
            setLoading(true);
            let responseData;
            if (payload) {
                responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getProducts */ .Z.getProducts(payload);
            } else {
                const queries = {
                    _limit: 12
                };
                responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getProducts */ .Z.getProducts(queries);
            }
            if (responseData) {
                setProductItems(responseData);
                setTimeout((function() {
                    setLoading(false);
                }).bind(this), 250);
            }
        },
        getProductById: async (payload)=>{
            setLoading(true);
            const responseData = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getProductsById */ .Z.getProductsById(payload);
            if (responseData) {
                setProduct(responseData);
                setTimeout((function() {
                    setLoading(false);
                }).bind(this), 250);
            }
        }
    };
};


/***/ })

};
;