"use strict";
exports.id = 3284;
exports.ids = [3284];
exports.modules = {

/***/ 3284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ products_ProductWide)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./utilities/product-helper.js
var product_helper = __webpack_require__(8798);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./hooks/useProduct.js
var useProduct = __webpack_require__(6922);
// EXTERNAL MODULE: ./hooks/useEcomerce.js
var useEcomerce = __webpack_require__(1440);
;// CONCATENATED MODULE: ./components/elements/products/modules/ModuleProductWideActions.js






const ModuleProductWideActions = ({ ecomerce , product  })=>{
    const { price  } = (0,useProduct/* default */.Z)();
    const { addItem  } = (0,useEcomerce/* default */.Z)();
    function handleAddItemToCart(e) {
        e.preventDefault();
        addItem({
            id: product.id,
            quantity: 1
        }, ecomerce.cartItems, 'cart');
    }
    function handleAddItemToWishlist(e) {
        e.preventDefault();
        addItem({
            id: product.id
        }, ecomerce.wishlistItems, 'wishlist');
        const modal = external_antd_.Modal.success({
            centered: true,
            title: 'Success!',
            content: `This item has been added to your wishlist`
        });
        modal.update;
    }
    function handleAddItemToCompare(e) {
        e.preventDefault();
        addItem({
            id: product.id
        }, ecomerce.compareItems, 'compare');
        const modal = external_antd_.Modal.success({
            centered: true,
            title: 'Success!',
            content: `This product has been added to your compare listing!`
        });
        modal.update;
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "ps-product__shopping",
        children: [
            price(product),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                className: "ps-btn",
                href: "#",
                onClick: (e)=>handleAddItemToCart(e)
                ,
                children: "Add to cart"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "ps-product__actions",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "#",
                            onClick: (e)=>handleAddItemToWishlist(e)
                            ,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                                    className: "icon-heart"
                                }),
                                " Wishlist"
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            href: "#",
                            onClick: (e)=>handleAddItemToCompare(e)
                            ,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                                    className: "icon-chart-bars"
                                }),
                                " Compare"
                            ]
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const modules_ModuleProductWideActions = ((0,external_react_redux_.connect)((state)=>state
)(ModuleProductWideActions));

;// CONCATENATED MODULE: ./components/elements/products/ProductWide.jsx






const ProductWide = ({ product  })=>{
    const { thumbnailImage , price , title , badge  } = (0,useProduct/* default */.Z)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "ps-product ps-product--wide",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "ps-product__thumbnail",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                    href: "/product/[pid]",
                    as: `/product/${product.id}`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                        children: thumbnailImage(product)
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "ps-product__container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ps-product__content",
                        children: [
                            title(product),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "ps-product__vendor",
                                children: [
                                    "Sold by:",
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                                        href: "/shop",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                                            children: product.vendor
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: "ps-product__desc",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                        children: "Unrestrained and portable active stereo speaker"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                        children: " Free from the confines of wires and chords"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                        children: " 20 hours of portable capabilities"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                        children: "Double-ended Coil Cord with 3.5mm Stereo Plugs Included"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                        children: " 3/4″ Dome Tweeters: 2X and 4″ Woofer: 1X"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(modules_ModuleProductWideActions, {
                        product: product
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const products_ProductWide = (ProductWide);


/***/ })

};
;