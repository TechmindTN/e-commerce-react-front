"use strict";
exports.id = 5030;
exports.ids = [5030];
exports.modules = {

/***/ 5030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_PageContainer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/shared/headers/HeaderDefault.jsx
var HeaderDefault = __webpack_require__(7840);
// EXTERNAL MODULE: ./components/shared/headers/HeaderMobile.jsx
var HeaderMobile = __webpack_require__(5533);
// EXTERNAL MODULE: ./components/shared/footers/modules/FooterWidgets.jsx
var FooterWidgets = __webpack_require__(4188);
// EXTERNAL MODULE: ./components/shared/footers/modules/FooterLinks.jsx
var FooterLinks = __webpack_require__(2324);
// EXTERNAL MODULE: ./components/shared/footers/modules/FooterCopyright.jsx
var FooterCopyright = __webpack_require__(3305);
;// CONCATENATED MODULE: ./components/shared/footers/FooterFullwidth.jsx





const FooterFullwidth = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsx)("footer", {
        className: "ps-footer",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "ps-container",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsx)(FooterWidgets/* default */.Z, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)(FooterLinks/* default */.Z, {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)(FooterCopyright/* default */.Z, {})
            ]
        })
    })
;
/* harmony default export */ const footers_FooterFullwidth = (FooterFullwidth);

;// CONCATENATED MODULE: ./components/layouts/PageContainer.jsx






const initHeaders = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [
        /*#__PURE__*/ (0,jsx_runtime_.jsx)(HeaderDefault/* default */.Z, {}),
        /*#__PURE__*/ (0,jsx_runtime_.jsx)(HeaderMobile/* default */.Z, {})
    ]
});
const initFooters = /*#__PURE__*/ (0,jsx_runtime_.jsx)(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(footers_FooterFullwidth, {})
});
const PageContainer = ({ header =initHeaders , footer =initFooters , children , title ='Page' ,  })=>{
    let titleView;
    if (title !== '') {
        titleView = "Martfury" + ' | ' + title;
    } else {
        titleView = "Martfury" + ' | ' + "Multipurpose Marketplace React Ecommerce Template";
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)((head_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("title", {
                    children: titleView
                })
            }),
            header,
            children,
            footer
        ]
    }));
};
/* harmony default export */ const layouts_PageContainer = (PageContainer);


/***/ }),

/***/ 5533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_CurrencyDropdown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7834);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var _modules_LanguageSwicher__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8538);
/* harmony import */ var _modules_MobileHeaderActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1322);






class HeaderMobile extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
    constructor({ props  }){
        super(props);
    }
    render() {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
            className: "header header--mobile",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "header__top",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "header__left",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                children: "Welcome to Martfury Online Shopping Store !"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "header__right",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "navigation__extra",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                            href: "/vendor/become-a-vendor",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                children: "Sell on Martfury"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                            href: "/account/order-tracking",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                children: "Tract your order"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_modules_CurrencyDropdown__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_modules_LanguageSwicher__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "navigation--mobile",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "navigation__left",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                                href: "/",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: "ps-logo",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                                        src: "/static/img/logo_light.png",
                                        alt: "martfury"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_modules_MobileHeaderActions__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "ps-search--mobile",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("form", {
                        className: "ps-form--search-mobile",
                        action: "/",
                        method: "get",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group--nest",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                    className: "form-control",
                                    type: "text",
                                    placeholder: "Search something..."
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                        className: "icon-magnifier"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        }));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderMobile);


/***/ }),

/***/ 1322:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modules_MobileHeaderActions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./store/auth/action.js
var action = __webpack_require__(2224);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
;// CONCATENATED MODULE: ./components/shared/headers/modules/AccountQuickLinksMobile.jsx






class AccountQuickLinks extends external_react_.Component {
    constructor(props){
        super(props);
    }
    handleLogout = (e)=>{
        e.preventDefault();
        this.props.dispatch((0,action/* logOut */.ni)());
    };
    render() {
        const accountLinks = [
            {
                text: 'Account Information',
                url: '/account/user-information'
            },
            {
                text: 'Notifications',
                url: '/account/notifications'
            },
            {
                text: 'Invoices',
                url: '/account/invoices'
            },
            {
                text: 'Address',
                url: '/account/addresses'
            },
            {
                text: 'Recent Viewed Product',
                url: '/account/recent-viewed-product'
            },
            {
                text: 'Wishlist',
                url: '/account/wishlist'
            }, 
        ];
        const menu = /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Menu, {
            children: [
                accountLinks.map((link)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)(external_antd_.Menu.Item, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                            href: link.url,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                                children: link.text
                            })
                        })
                    }, link.url)
                ),
                /*#__PURE__*/ (0,jsx_runtime_.jsx)(external_antd_.Menu.Item, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                        href: "#",
                        onClick: this.handleLogout.bind(this),
                        children: "Logout"
                    })
                })
            ]
        });
        return(/*#__PURE__*/ (0,jsx_runtime_.jsx)(external_antd_.Dropdown, {
            overlay: menu,
            placement: "bottomLeft",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                href: "#",
                className: "header__extra ps-user--mobile",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                    className: "icon-user"
                })
            })
        }));
    }
}
const mapStateToProps = (state)=>{
    return state;
};
/* harmony default export */ const AccountQuickLinksMobile = ((0,external_react_redux_.connect)(mapStateToProps)(AccountQuickLinks));

;// CONCATENATED MODULE: ./components/shared/headers/modules/MobileHeaderActions.jsx





const MobileHeaderActions = ({ auth , ecomerce  })=>{
    const { cartItems  } = ecomerce;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "navigation__right",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                href: "/account/shopping-cart",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: "header__extra",
                    href: "#",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                            className: "icon-bag2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                                children: cartItems ? cartItems.length : 0
                            })
                        })
                    ]
                })
            }),
            auth.isLoggedIn && Boolean(auth.isLoggedIn) === true ? /*#__PURE__*/ (0,jsx_runtime_.jsx)(AccountQuickLinksMobile, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "header__extra",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                    href: "/account/login",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-user"
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const modules_MobileHeaderActions = ((0,external_react_redux_.connect)((state)=>state
)(MobileHeaderActions));


/***/ })

};
;