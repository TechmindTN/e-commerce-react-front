"use strict";
exports.id = 4756;
exports.ids = [4756];
exports.modules = {

/***/ 132:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useEcomerce__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1440);




const ModuleDetailActionsMobile = ({ ecomerce , product  })=>{
    const { addItem  } = (0,_hooks_useEcomerce__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const handleAddItemToCart = (e)=>{
        e.preventDefault();
        addItem({
            id: product.id,
            quantity: 1
        }, ecomerce.cartItems, 'cart');
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-product__actions-mobile",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "ps-btn ps-btn--black",
                href: "#",
                onClick: (e)=>handleAddItemToCart(e)
                ,
                children: "Add to cart"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "ps-btn",
                href: "#",
                onClick: (e)=>handleAddItemToCart(e)
                ,
                children: "Buy Now"
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)((state)=>state
)(ModuleDetailActionsMobile));


/***/ }),

/***/ 3618:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useEcomerce__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1440);






const ModuleDetailShoppingActions = ({ ecomerce , product , extended =false ,  })=>{
    const { 0: quantity , 1: setQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const Router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { addItem  } = (0,_hooks_useEcomerce__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    function handleAddItemToCart(e) {
        e.preventDefault();
        addItem({
            id: product.id,
            quantity: quantity
        }, ecomerce.cartItems, 'cart');
    }
    function handleBuynow(e) {
        e.preventDefault();
        addItem({
            id: product.id,
            quantity: quantity
        }, ecomerce.cartItems, 'cart');
        setTimeout(function() {
            Router.push('/account/checkout');
        }, 1000);
    }
    const handleAddItemToCompare = (e)=>{
        e.preventDefault();
        e.preventDefault();
        addItem({
            id: product.id
        }, ecomerce.compareItems, 'compare');
        const modal = antd__WEBPACK_IMPORTED_MODULE_4__.Modal.success({
            centered: true,
            title: 'Success!',
            content: `This product has been added to compare listing!`
        });
        modal.update;
    };
    const handleAddItemToWishlist = (e)=>{
        e.preventDefault();
        addItem({
            id: product.id
        }, ecomerce.wishlistItems, 'wishlist');
        const modal = antd__WEBPACK_IMPORTED_MODULE_4__.Modal.success({
            centered: true,
            title: 'Success!',
            content: `This item has been added to your wishlist`
        });
        modal.update;
    };
    function handleIncreaseItemQty(e) {
        e.preventDefault();
        setQuantity(quantity + 1);
    }
    function handleDecreaseItemQty(e) {
        e.preventDefault();
        if (quantity > 1) {
            setQuantity(quantity - 1);
        }
    }
    if (!extended) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "ps-product__shopping",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("figure", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("figcaption", {
                            children: "Quantity"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form-group--number",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                    className: "up",
                                    onClick: (e)=>handleIncreaseItemQty(e)
                                    ,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                        className: "fa fa-plus"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                    className: "down",
                                    onClick: (e)=>handleDecreaseItemQty(e)
                                    ,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                        className: "fa fa-minus"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                    className: "form-control",
                                    type: "text",
                                    placeholder: quantity,
                                    disabled: true
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    className: "ps-btn ps-btn--black",
                    href: "#",
                    onClick: (e)=>handleAddItemToCart(e)
                    ,
                    children: "Add to cart"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    className: "ps-btn",
                    href: "#",
                    onClick: (e)=>handleBuynow(e)
                    ,
                    children: "Buy Now"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "ps-product__actions",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            href: "#",
                            onClick: (e)=>handleAddItemToWishlist(e)
                            ,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                className: "icon-heart"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            href: "#",
                            onClick: (e)=>handleAddItemToCompare(e)
                            ,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                className: "icon-chart-bars"
                            })
                        })
                    ]
                })
            ]
        }));
    } else {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "ps-product__shopping extend",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "ps-product__btn-group",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("figure", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("figcaption", {
                                    children: "Quantity"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-group--number",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                            className: "up",
                                            onClick: (e)=>handleIncreaseItemQty(e)
                                            ,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                className: "fa fa-plus"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("button", {
                                            className: "down",
                                            onClick: (e)=>handleDecreaseItemQty(e)
                                            ,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                className: "fa fa-minus"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("input", {
                                            className: "form-control",
                                            type: "text",
                                            placeholder: quantity,
                                            disabled: true
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            className: "ps-btn ps-btn--black",
                            href: "#",
                            onClick: (e)=>handleAddItemToCart(e)
                            ,
                            children: "Add to cart"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "ps-product__actions",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    href: "#",
                                    onClick: (e)=>handleAddItemToWishlist(e)
                                    ,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                        className: "icon-heart"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    href: "#",
                                    onClick: (e)=>handleAddItemToCompare(e)
                                    ,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                        className: "icon-chart-bars"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    className: "ps-btn",
                    href: "#",
                    onClick: (e)=>handleBuynow(e)
                    ,
                    children: "Buy Now"
                })
            ]
        }));
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)((state)=>state
)(ModuleDetailShoppingActions));


/***/ }),

/***/ 2784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var _components_elements_Rating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7660);




const ModuleDetailTopInformation = ({ product  })=>{
    // Views
    let priceView;
    if (product.is_sale) {
        priceView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
            className: "ps-product__price sale",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("del", {
                    className: "mr-2",
                    children: [
                        "&",
                        product.sale_price
                    ]
                }),
                "$",
                product.price
            ]
        });
    } else {
        priceView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
            className: "ps-product__price",
            children: [
                "$",
                product.price
            ]
        });
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h1", {
                children: product.title
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "ps-product__meta",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            "Brand:",
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                href: "/shop",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    className: "ml-2 text-capitalize",
                                    children: product.vendor
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ps-product__rating",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_Rating__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                                children: "(1 review)"
                            })
                        ]
                    })
                ]
            }),
            priceView
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModuleDetailTopInformation);


/***/ }),

/***/ 9129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



const ModuleProductDetailDescription = ({ product  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-product__desc",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    "Sold By:",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                children: [
                                    " ",
                                    product.vendor
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: "ps-list--dot",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                        children: "Unrestrained and portable active stereo speaker"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                        children: " Free from the confines of wires and chords"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                        children: " 20 hours of portable capabilities"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                        children: "Double-ended Coil Cord with 3.5mm Stereo Plugs Included"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                        children: " 3/4″ Dome Tweeters: 2X and 4″ Woofer: 1X"
                    })
                ]
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModuleProductDetailDescription);


/***/ }),

/***/ 7939:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ModuleProductDetailSharing = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-product__sharing",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "facebook",
                href: "#",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                    className: "fa fa-facebook"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "twitter",
                href: "#",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                    className: "fa fa-twitter"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "google",
                href: "#",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                    className: "fa fa-google-plus"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "linkedin",
                href: "#",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                    className: "fa fa-linkedin"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                className: "instagram",
                href: "#",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                    className: "fa fa-instagram"
                })
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModuleProductDetailSharing);


/***/ }),

/***/ 9082:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



const ModuleProductDetailSpecification = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-product__specification",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                href: "/page/blank",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    className: "report",
                    children: "Report Abuse"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "SKU:"
                    }),
                    " SF1133569600-1"
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "categories",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: " Categories:"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: "Consumer Electronics"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: "Refrigerator"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: "Babies & Moms"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "tags",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: " Tags"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: "sofa"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: "technologies"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/shop",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                            children: "wireless"
                        })
                    })
                ]
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModuleProductDetailSpecification);


/***/ }),

/***/ 9508:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4990);
/* harmony import */ var react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_image_lightbox__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _repositories_Repository__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8833);
/* harmony import */ var _components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9387);
/* harmony import */ var _components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9768);







const ThumbnailDefault = ({ product , vertical =true  })=>{
    const galleryCarousel = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const variantCarousel = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: gallery , 1: setGallery  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: variant , 1: setVariant  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: isOpen , 1: setIsOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: photoIndex , 1: setPhotoIndex  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: productImages , 1: setProductImages  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const handleOpenLightbox = (e, imageIndex)=>{
        e.preventDefault();
        setPhotoIndex(imageIndex);
        setIsOpen(true);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let images = [];
        if (product && product.images.length > 0) {
            product.images.map((item)=>{
                images.push(`${_repositories_Repository__WEBPACK_IMPORTED_MODULE_4__/* .baseUrl */ .FH}${item.url}`);
            });
            setProductImages(images);
        }
        setGallery(galleryCarousel.current);
        setVariant(variantCarousel.current);
    }, [
        product
    ]);
    const gallerySetting = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        nextArrow: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
        prevArrow: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
    };
    const variantSetting = {
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    dots: false,
                    arrows: false,
                    vertical: false,
                    infinite: false
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 4,
                    dots: false,
                    arrows: false,
                    vertical: false,
                    infinite: false
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 4,
                    dots: false,
                    arrows: false,
                    vertical: false,
                    infinite: false
                }
            }, 
        ]
    };
    //Views
    let lightboxView, variantCarouselView, imagesView, galleryImagesView;
    if (productImages.length > 0) {
        imagesView = productImages.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "item",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                    src: item,
                    alt: item
                })
            }, item)
        );
        galleryImagesView = productImages.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "item",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    href: "#",
                    onClick: (e)=>handleOpenLightbox(e, index)
                    ,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                        src: item,
                        alt: item
                    })
                })
            }, item)
        );
    }
    if (vertical) {
        variantCarouselView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
            asNavFor: gallery,
            ref: (slider)=>variantCarousel.current = slider
            ,
            swipeToSlide: true,
            arrows: false,
            slidesToShow: 3,
            vertical: true,
            infinite: true,
            focusOnSelect: true,
            ...variantSetting,
            className: "ps-product__variants",
            children: imagesView
        });
    } else {
        variantCarouselView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
            asNavFor: gallery,
            ref: (slider)=>variantCarousel.current = slider
            ,
            swipeToSlide: true,
            arrows: false,
            slidesToShow: 6,
            vertical: false,
            centered: true,
            infinite: false,
            focusOnSelect: true,
            className: "ps-product__variants",
            children: imagesView
        });
    }
    if (isOpen) {
        lightboxView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_image_lightbox__WEBPACK_IMPORTED_MODULE_3___default()), {
            mainSrc: productImages[photoIndex],
            nextSrc: productImages[(photoIndex + 1) % productImages.length],
            prevSrc: productImages[(photoIndex + productImages.length - 1) % productImages.length],
            onCloseRequest: ()=>{
                setIsOpen(false);
            },
            onMovePrevRequest: ()=>{
                setPhotoIndex((photoIndex + productImages.length - 1) % productImages.length);
            },
            onMoveNextRequest: ()=>{
                setPhotoIndex((photoIndex + 1) % productImages.length);
            }
        });
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-product__thumbnail",
        "data-vertical": vertical ? 'true' : 'false',
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("figure", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "ps-wrapper",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
                        ...gallerySetting,
                        ref: (slider)=>galleryCarousel.current = slider
                        ,
                        asNavFor: variant,
                        className: "ps-product__gallery ps-carousel inside",
                        children: galleryImagesView
                    })
                })
            }),
            variantCarouselView,
            lightboxView
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ThumbnailDefault);


/***/ }),

/***/ 4756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modules_ModuleProductActions)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./components/elements/detail/thumbnail/ThumbnailDefault.jsx
var ThumbnailDefault = __webpack_require__(9508);
// EXTERNAL MODULE: ./components/elements/detail/modules/ModuleDetailTopInformation.jsx
var ModuleDetailTopInformation = __webpack_require__(2784);
// EXTERNAL MODULE: ./components/elements/detail/modules/ModuleProductDetailDescription.js
var ModuleProductDetailDescription = __webpack_require__(9129);
// EXTERNAL MODULE: ./components/elements/detail/modules/ModuleDetailShoppingActions.jsx
var ModuleDetailShoppingActions = __webpack_require__(3618);
// EXTERNAL MODULE: ./components/elements/detail/modules/ModuleProductDetailSpecification.js
var ModuleProductDetailSpecification = __webpack_require__(9082);
// EXTERNAL MODULE: ./components/elements/detail/modules/ModuleProductDetailSharing.js
var ModuleProductDetailSharing = __webpack_require__(7939);
// EXTERNAL MODULE: ./components/elements/detail/modules/ModuleDetailActionsMobile.jsx
var ModuleDetailActionsMobile = __webpack_require__(132);
;// CONCATENATED MODULE: ./components/elements/detail/ProductDetailQuickView.jsx









const ProductDetailQuickView = ({ product  })=>/*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
        className: "ps-product--detail ps-product--quickview",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "ps-product__header",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsx)(ThumbnailDefault/* default */.Z, {
                    product: product,
                    vertical: false
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "ps-product__info",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(ModuleDetailTopInformation/* default */.Z, {
                            product: product
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(ModuleProductDetailDescription/* default */.Z, {
                            product: product
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(ModuleDetailShoppingActions/* default */.Z, {
                            product: product,
                            extended: true
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(ModuleProductDetailSpecification/* default */.Z, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(ModuleProductDetailSharing/* default */.Z, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsx)(ModuleDetailActionsMobile/* default */.Z, {})
                    ]
                })
            ]
        })
    })
;
/* harmony default export */ const detail_ProductDetailQuickView = (ProductDetailQuickView);

// EXTERNAL MODULE: ./hooks/useEcomerce.js
var useEcomerce = __webpack_require__(1440);
;// CONCATENATED MODULE: ./components/elements/products/modules/ModuleProductActions.js






const ModuleProductActions = ({ product , ecomerce  })=>{
    const { 0: isQuickView , 1: setIsQuickView  } = (0,external_react_.useState)(false);
    const { addItem  } = (0,useEcomerce/* default */.Z)();
    function handleAddItemToCart(e) {
        e.preventDefault();
        addItem({
            id: product.id,
            quantity: 1
        }, ecomerce.cartItems, 'cart');
    }
    function handleAddItemToWishlist(e) {
        e.preventDefault();
        addItem({
            id: product.id
        }, ecomerce.wishlistItems, 'wishlist');
        const modal = external_antd_.Modal.success({
            centered: true,
            title: 'Success!',
            content: `This item has been added to your wishlist`
        });
        modal.update;
    }
    function handleAddItemToCompare(e) {
        e.preventDefault();
        addItem({
            id: product.id
        }, ecomerce.compareItems, 'compare');
        const modal = external_antd_.Modal.success({
            centered: true,
            title: 'Success!',
            content: `This product has been added to your compare listing!`
        });
        modal.update;
    }
    const handleShowQuickView = (e)=>{
        e.preventDefault();
        setIsQuickView(true);
    };
    const handleHideQuickView = (e)=>{
        e.preventDefault();
        setIsQuickView(false);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
        className: "ps-product__actions",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    href: "#",
                    "data-toggle": "tooltip",
                    "data-placement": "top",
                    title: "Add To Cart",
                    onClick: handleAddItemToCart,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-bag2"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    href: "#",
                    "data-toggle": "tooltip",
                    "data-placement": "top",
                    title: "Quick View",
                    onClick: handleShowQuickView,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-eye"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    href: "#",
                    "data-toggle": "tooltip",
                    "data-placement": "top",
                    title: "Add to wishlist",
                    onClick: handleAddItemToWishlist,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-heart"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    href: "#",
                    "data-toggle": "tooltip",
                    "data-placement": "top",
                    title: "Compare",
                    onClick: handleAddItemToCompare,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-chart-bars"
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_antd_.Modal, {
                centered: true,
                footer: null,
                width: 1024,
                onCancel: (e)=>handleHideQuickView(e)
                ,
                visible: isQuickView,
                closeIcon: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                    className: "icon icon-cross2"
                }),
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("h3", {
                        children: "Quickview"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)(detail_ProductDetailQuickView, {
                        product: product
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const modules_ModuleProductActions = ((0,external_react_redux_.connect)((state)=>state
)(ModuleProductActions));


/***/ })

};
;