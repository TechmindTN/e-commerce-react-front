"use strict";
exports.id = 7857;
exports.ids = [7857];
exports.modules = {

/***/ 7857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7706);
/* harmony import */ var _utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1675);
/* harmony import */ var _components_elements_products_Product__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1760);
/* harmony import */ var _utilities_carousel_helpers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3780);
/* harmony import */ var _components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9387);
/* harmony import */ var _components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9768);
/* harmony import */ var _hooks_useGetProducts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2933);










const ProductGroupByCarousel = ({ collectionSlug , title , layout ='standard' ,  })=>{
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { productItems , loading , getProductsByCollection  } = (0,_hooks_useGetProducts__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getProductsByCollection(collectionSlug);
    }, [
        collectionSlug
    ]);
    const handleCarouselPrev = (e)=>{
        e.preventDefault();
        sliderRef.current.slickPrev();
    };
    const handleCarouselNext = (e)=>{
        e.preventDefault();
        sliderRef.current.slickNext();
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getProductsByCollection(collectionSlug);
    }, [
        collectionSlug
    ]);
    const carouselFullwidth = {
        dots: false,
        infinite: productItems && productItems.length > 7 ? true : false,
        speed: 750,
        slidesToShow: 7,
        slidesToScroll: 3,
        arrows: true,
        nextArrow: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_carousel_NextArrow__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
        prevArrow: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_carousel_PrevArrow__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
        lazyload: true,
        responsive: [
            {
                breakpoint: 1750,
                settings: {
                    slidesToShow: 6,
                    slidesToScroll: 3,
                    dots: true,
                    arrows: false
                }
            },
            {
                breakpoint: 1366,
                settings: {
                    slidesToShow: 5,
                    slidesToScroll: 2,
                    infinite: true,
                    dots: true,
                    arrows: false
                }
            },
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 2,
                    dots: true,
                    arrows: false
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 2,
                    dots: true,
                    arrows: false
                }
            }, 
        ]
    };
    // Views
    let productItemsView;
    if (!loading) {
        if (productItems && productItems.length > 0) {
            const slideItems = productItems.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_products_Product__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    product: item
                }, item.id)
            );
            if (layout !== 'standard') {
                productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
                    ref: (slider)=>sliderRef.current = slider
                    ,
                    ...carouselFullwidth,
                    arrows: false,
                    className: "ps-carousel outside",
                    children: slideItems
                });
            } else {
                productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)((react_slick__WEBPACK_IMPORTED_MODULE_2___default()), {
                    ref: (slider)=>sliderRef.current = slider
                    ,
                    ..._utilities_carousel_helpers__WEBPACK_IMPORTED_MODULE_5__/* .carouselStandard */ .aL,
                    arrows: false,
                    className: "ps-carousel outside",
                    children: slideItems
                });
            }
        } else {
            productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                children: "No product found."
            });
        }
    } else {
        const skeletons = (0,_utilities_common_helpers__WEBPACK_IMPORTED_MODULE_9__/* .generateTempArray */ .Z)(6).map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "col-xl-2 col-lg-3 col-sm-3 col-6",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_skeletons_SkeletonProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            }, item)
        );
        productItemsView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
            className: "row",
            children: skeletons
        });
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-block--shop-features",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "ps-block__header",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
                        children: title
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ps-block__navigation",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                className: "ps-carousel__prev",
                                onClick: (e)=>handleCarouselPrev(e)
                                ,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                    className: "icon-chevron-left"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                className: "ps-carousel__next",
                                onClick: (e)=>handleCarouselNext(e)
                                ,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                    className: "icon-chevron-right"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "ps-block__content",
                children: productItemsView
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductGroupByCarousel);


/***/ })

};
;