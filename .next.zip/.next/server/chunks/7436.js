"use strict";
exports.id = 7436;
exports.ids = [7436];
exports.modules = {

/***/ 572:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8833);

class CollectionRepository {
    async getCollections(payload) {
        let query = '';
        payload.forEach((item)=>{
            if (query === '') {
                query = `slug_in=${item}`;
            } else {
                query = query + `&slug_in=${item}`;
            }
        });
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/collections?${query}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getCategoriesBySlug(payload) {
        let query = '';
        payload.forEach((item)=>{
            if (query === '') {
                query = `slug_in=${item}`;
            } else {
                query = query + `&slug_in=${item}`;
            }
        });
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/product-categories?${query}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getProductsByCollectionSlug(slug) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/collections?slug_in=${slug}`).then((response)=>{
            if (response.data && response.data.length > 0) {
                return {
                    items: response.data[0].products
                };
            } else {
                return null;
            }
            return response.data;
        }).catch((error)=>{
            console.log(JSON.stringify(error));
            return null;
        });
        return reponse;
    }
    async getProductsByCategorySlug(slug) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .baseUrl */ .FH}/product-categories?slug_in=${slug}`).then((response)=>{
            if (response.data && response.data.length > 0) {
                return {
                    items: response.data[0].products
                };
            } else {
                return null;
            }
            return response.data;
        }).catch((error)=>{
            console.log(JSON.stringify(error));
            return null;
        });
        return reponse;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new CollectionRepository());


/***/ }),

/***/ 7436:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ getProductsByCollectionHelper),
/* harmony export */   "b": () => (/* binding */ getProductsByCategoriesHelper)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _repositories_CollectionRepository__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(572);
/* harmony import */ var _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3328);
/*
 * React template helpers
 * Author: Nouthemes
 * Developed: diaryforlife
 * */ 


async function getProductsByCollectionHelper(collectionSlug, pageSize = 12) {
    let products;
    if (collectionSlug) {
        products = await _repositories_CollectionRepository__WEBPACK_IMPORTED_MODULE_1__/* ["default"].getProductsByCollectionSlug */ .Z.getProductsByCollectionSlug(collectionSlug);
    } else {
        const queries = {
            _limit: pageSize
        };
        products = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getRecords */ .Z.getRecords(queries);
    }
    if (products) {
        return products;
    } else {
        return null;
    }
}
async function getProductsByCategoriesHelper(slug, pageSize = 12) {
    let products;
    if (slug) {
        products = await _repositories_CollectionRepository__WEBPACK_IMPORTED_MODULE_1__/* ["default"].getProductsByCategorySlug */ .Z.getProductsByCategorySlug(slug);
    } else {
        const queries = {
            _limit: pageSize
        };
        products = await _repositories_ProductRepository__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getRecords */ .Z.getRecords(queries);
    }
    if (products) {
        return products;
    } else {
        return null;
    }
}


/***/ })

};
;