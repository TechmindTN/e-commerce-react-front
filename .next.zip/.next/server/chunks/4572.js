"use strict";
exports.id = 4572;
exports.ids = [4572];
exports.modules = {

/***/ 7660:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Rating = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        className: "ps-rating",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                className: "fa fa-star"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                className: "fa fa-star"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                className: "fa fa-star"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                className: "fa fa-star"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                className: "fa fa-star-o"
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Rating);


/***/ }),

/***/ 2714:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



const Logo = ({ type  })=>{
    let data;
    if (type === 'autopart') {
        data = {
            url: '/home/autopart',
            img: 'img/logo-autopart.png'
        };
    } else if (type === 'technology') {
        data = {
            url: '/home/technology',
            img: 'static/img/logo-technology.png'
        };
    } else if (type === 'technology') {
        data = {
            url: '/home/technology',
            img: 'static/img/logo-technology.png'
        };
    } else if (type === 'electronic') {
        data = {
            url: '/home/electronic',
            img: 'static/img/logo-electronic.png'
        };
    } else if (type === 'furniture') {
        data = {
            url: '/home/furniture',
            img: 'static/img/logo-furniture.png'
        };
    } else if (type === 'organic') {
        data = {
            url: '/home/organic',
            img: 'static/img/logo-organic.png'
        };
    } else {
        data = {
            url: '/',
            img: '/static/img/logo_light.png'
        };
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
        href: data.url,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
            className: "ps-logo",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                src: data.img,
                alt: ""
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);


/***/ }),

/***/ 2222:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ menu_Menu)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/elements/menu/MenuDropdown.jsx



const MenuDropdown = ({ source  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: "menu-item-has-children dropdown",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                href: source.url,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    children: source.text
                })
            }),
            source.subMenu && /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                className: source.subClass,
                children: source.subMenu.map((subMenuItem, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)(MenuDropdown, {
                        source: subMenuItem
                    }, index)
                )
            })
        ]
    }));
};
/* harmony default export */ const menu_MenuDropdown = (MenuDropdown);

;// CONCATENATED MODULE: ./components/elements/menu/MegaMenu.jsx



const MegaMenu = ({ source  })=>{
    let megaContentView;
    if (source) {
        megaContentView = source.megaContent.map((item)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mega-menu__column",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("h4", {
                        children: item.heading
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
                        className: "mega-menu__list",
                        children: item.megaItems.map((subItem)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                                    href: subItem.url,
                                    as: subItem.url,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                                        children: subItem.text
                                    })
                                })
                            }, subItem.text)
                        )
                    })
                ]
            }, item.heading)
        );
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: "menu-item-has-children has-mega-menu",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                href: source.url !== '' ? source.url : '/',
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    children: [
                        source.icon && /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                            className: source.icon
                        }),
                        source.text
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "mega-menu",
                children: megaContentView
            })
        ]
    }));
};
/* harmony default export */ const menu_MegaMenu = (MegaMenu);

;// CONCATENATED MODULE: ./components/elements/menu/Menu.jsx





const Menu = ({ source , className  })=>{
    // Views
    let menuView;
    if (source) {
        menuView = source.map((item)=>{
            if (item.subMenu) {
                return(/*#__PURE__*/ (0,jsx_runtime_.jsx)(menu_MenuDropdown, {
                    source: item
                }, item.text));
            } else if (item.megaContent) {
                return(/*#__PURE__*/ (0,jsx_runtime_.jsx)(menu_MegaMenu, {
                    source: item
                }, item.text));
            } else {
                return(/*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                        href: item.url,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            children: [
                                item.icon && /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                                    className: item.icon
                                }),
                                item.text
                            ]
                        })
                    })
                }, item.text));
            }
        });
    } else {
        menuView = /*#__PURE__*/ (0,jsx_runtime_.jsx)("li", {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                href: "#",
                onClick: (e)=>e.preventDefault()
                ,
                children: "No menu item."
            })
        });
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsx)("ul", {
        className: className,
        children: menuView
    }));
};
/* harmony default export */ const menu_Menu = (Menu);


/***/ }),

/***/ 3305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const FooterCopyright = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-footer__copyright",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                children: "\xa9  2021 Martfury. All Rights Reserved"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                        children: "We Using Safe Payment For:"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "#",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: "/static/img/payment-method/1.jpg",
                            alt: "Martfury"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "#",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: "/static/img/payment-method/2.jpg",
                            alt: "Martfury"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "#",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: "/static/img/payment-method/3.jpg",
                            alt: "Martfury"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "#",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: "/static/img/payment-method/4.jpg",
                            alt: "Martfury"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                        href: "#",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("img", {
                            src: "/static/img/payment-method/5.jpg",
                            alt: "Martfury"
                        })
                    })
                ]
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterCopyright);


/***/ }),

/***/ 2324:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



const Links = {
    consumerElectric: [
        {
            text: 'Air Conditioners',
            url: '/shop'
        },
        {
            text: 'Audios & Theaters',
            url: '/shop'
        },
        {
            text: 'Car Electronics',
            url: '/shop'
        },
        {
            text: 'Office Electronics',
            url: '/shop'
        },
        {
            text: 'TV Televisions',
            url: '/shop'
        },
        {
            text: 'Washing Machines',
            url: '/shop'
        }, 
    ],
    clothingAndApparel: [
        {
            text: 'Printers',
            url: '/shop'
        },
        {
            text: 'Projectors',
            url: '/shop'
        },
        {
            text: 'Scanners',
            url: '/shop'
        },
        {
            text: 'Store & Business',
            url: '/shop'
        },
        {
            text: '4K Ultra HD TVs',
            url: '/shop'
        },
        {
            text: 'LED TVs',
            url: '/shop'
        },
        {
            text: 'OLED TVs',
            url: '/shop'
        }, 
    ],
    gardenAndKitchen: [
        {
            text: 'Cookware',
            url: '/shop'
        },
        {
            text: 'Decoration',
            url: '/shop'
        },
        {
            text: 'Furniture',
            url: '/shop'
        },
        {
            text: 'Garden Tools',
            url: '/shop'
        },
        {
            text: 'Garden Equipments',
            url: '/shop'
        },
        {
            text: 'Powers And Hand Tools',
            url: '/shop'
        },
        {
            text: 'Utensil & Gadget',
            url: '/shop'
        }, 
    ],
    healthAndBeauty: [
        {
            text: 'Hair Care',
            url: '/shop'
        },
        {
            text: 'Decoration',
            url: '/shop'
        },
        {
            text: 'Makeup',
            url: '/shop'
        },
        {
            text: 'Body Shower',
            url: '/shop'
        },
        {
            text: 'Skin Care',
            url: '/shop'
        },
        {
            text: 'Cologine',
            url: '/shop'
        },
        {
            text: 'Perfume',
            url: '/shop'
        }, 
    ],
    jewelryAndWatch: [
        {
            text: 'Necklace',
            url: '/shop'
        },
        {
            text: 'Pendant',
            url: '/shop'
        },
        {
            text: 'Diamond Ring',
            url: '/shop'
        },
        {
            text: 'Sliver Earing',
            url: '/shop'
        },
        {
            text: 'Leather Watcher',
            url: '/shop'
        },
        {
            text: 'Gucci',
            url: '/shop'
        }, 
    ],
    computerAndTechnology: [
        {
            text: 'Desktop PC',
            url: '/shop'
        },
        {
            text: 'Laptop',
            url: '/shop'
        },
        {
            text: 'Smartphones',
            url: '/shop'
        },
        {
            text: 'Tablet',
            url: '/shop'
        },
        {
            text: 'Game Controller',
            url: '/shop'
        },
        {
            text: 'Audio & Video',
            url: '/shop'
        },
        {
            text: 'Wireless Speaker',
            url: '/shop'
        }, 
    ]
};
const FooterLinks = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-footer__links",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "Consumer Electric:"
                    }),
                    Links.consumerElectric.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: item.url,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: item.text
                            })
                        }, item.text)
                    )
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "Clothing & Apparel:"
                    }),
                    Links.clothingAndApparel.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: item.url,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: item.text
                            })
                        }, item.text)
                    )
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "Home, Garden & Kitchen:"
                    }),
                    Links.gardenAndKitchen.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: item.url,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: item.text
                            })
                        }, item.text)
                    )
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "Health & Beauty:"
                    }),
                    Links.healthAndBeauty.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: item.url,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: item.text
                            })
                        }, item.text)
                    )
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "Jewelry & Watches:"
                    }),
                    Links.jewelryAndWatch.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: item.url,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: item.text
                            })
                        }, item.text)
                    )
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("strong", {
                        children: "Computer & Technologies:"
                    }),
                    Links.computerAndTechnology.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                            href: item.url,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: item.text
                            })
                        }, item.text)
                    )
                ]
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterLinks);


/***/ }),

/***/ 4188:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);



const FooterWidgets = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "ps-footer__widgets",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
                className: "widget widget_footer widget_contact-us",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", {
                        className: "widget-title",
                        children: "Contact us"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "widget_content",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("p", {
                                children: "Call us 24/7"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h3", {
                                children: "1800 97 97 69"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                children: [
                                    "502 New Design Str, Melbourne, Australia ",
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("br", {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        href: "mailto:contact@martfury.co",
                                        children: "contact@martfury.co"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "ps-list--social",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                            className: "facebook",
                                            href: "#",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                className: "fa fa-facebook"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                            className: "twitter",
                                            href: "#",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                className: "fa fa-twitter"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                            className: "google-plus",
                                            href: "#",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                className: "fa fa-google-plus"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                            className: "instagram",
                                            href: "#",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                                className: "fa fa-instagram"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
                className: "widget widget_footer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", {
                        className: "widget-title",
                        children: "Quick links"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "ps-list--link",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/blank",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Policy"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/blank",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Term & Condition"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/blank",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Shipping"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/blank",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Return"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/faqs",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "FAQs"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
                className: "widget widget_footer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", {
                        className: "widget-title",
                        children: "Company"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "ps-list--link",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/about-us",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "About Us"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/blank",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Affilate"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/blank",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Career"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/contact-us",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Contact"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("aside", {
                className: "widget widget_footer",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("h4", {
                        className: "widget-title",
                        children: "Bussiness"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "ps-list--link",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/page/about-us",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Our Press"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/account/checkout",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Checkout"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/account/user-information",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "My account"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                    href: "/shop",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                        children: "Shop"
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterWidgets);


/***/ }),

/***/ 7840:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2714);
/* harmony import */ var _components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9128);
/* harmony import */ var _components_shared_navigation_NavigationDefault__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6418);
/* harmony import */ var _components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5124);
/* harmony import */ var _components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9913);








const HeaderDefault = ()=>{
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, []);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: "header header--1",
        "data-sticky": "true",
        id: "headerSticky",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "header__top",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "ps-container",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "header__left",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_common_Logo__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "header__center",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_headers_modules_SearchHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                            className: "header__right",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_headers_modules_HeaderActions__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_navigation_NavigationDefault__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderDefault);


/***/ }),

/***/ 6500:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var _store_auth_action__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2224);





const AccountQuickLinks = (props)=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const handleLogout = (e)=>{
        e.preventDefault();
        dispatch((0,_store_auth_action__WEBPACK_IMPORTED_MODULE_4__/* .logOut */ .ni)());
    };
    const accountLinks = [
        {
            text: 'Account Information',
            url: '/account/user-information'
        },
        {
            text: 'Notifications',
            url: '/account/notifications'
        },
        {
            text: 'Invoices',
            url: '/account/invoices'
        },
        {
            text: 'Address',
            url: '/account/addresses'
        },
        {
            text: 'Recent Viewed Product',
            url: '/account/recent-viewed-product'
        },
        {
            text: 'Wishlist',
            url: '/account/wishlist'
        }, 
    ];
    const { isLoggedIn  } = props;
    // View
    const linksView = accountLinks.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                href: item.url,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                    children: item.text
                })
            })
        }, item.text)
    );
    if (isLoggedIn === true) {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "ps-block--user-account",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                    className: "icon-user"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "ps-block__content",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "ps-list--arrow",
                        children: [
                            linksView,
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                className: "ps-block__footer",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                    href: "#",
                                    onClick: (e)=>handleLogout(e)
                                    ,
                                    children: "Logout"
                                })
                            })
                        ]
                    })
                })
            ]
        }));
    } else {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "ps-block--user-header",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                    className: "ps-block__left",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                        className: "icon-user"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "ps-block__right",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                            href: "/account/login",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: "Login"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                            href: "/account/register",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                children: "Register"
                            })
                        })
                    ]
                })
            ]
        }));
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)((state)=>state
)(AccountQuickLinks));


/***/ }),

/***/ 7834:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);


//import { notification } from 'antd';
//import { connect } from 'react-redux';

//import { changeCurrency } from '../../../../store/setting/action';
function CurrencyDropdown() {
    const { 0: currency , 1: setCurrency  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(async ()=>{
        const result = await axios__WEBPACK_IMPORTED_MODULE_2___default()('https://ipapi.co/currency/');
        setCurrency(result.data);
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        children: currency
    }));
}
// const Currencydropdown = () => {
//     const [ip, setIP] = useState('');
// //creating function to load currency from the API
// const getData = async () => {
//     const res = await axios.get('https://ipapi.co/currency/')
//     console.log(res.data);
//     setIP(res.data)
//   }
//   useEffect( () => {
//     //passing getData method to the lifecycle method
//     getData()
//   }, [])
//     return (
//         <div>
//             {ip}
//         </div>
//     );
// }
// export default Currencydropdown;
//class CurrencyDropdown extends Component {
//     constructor(props) {
//         super(props);
//     }
//     handleFeatureWillUpdate(e) {
//         e.preventDefault();
//         notification.open({
//             message: 'Opp! Something went wrong.',
//             description: 'This feature has been updated later!',
//             duration: 500,
//         });
//     }
//     handleChangeCurrency = (e, currency) => {
//         e.preventDefault();
//         this.props.dispatch(changeCurrency(currency));
//     };
//    const 
//     render() {
//         const { currency } = this.props;
//         return (
//             <div className="ps-dropdown">
//                  {currency ? (
//                      <a href="/" onClick={e => e.preventDefault()}>
//                          {currency.text}
//                      </a>
//                  ) : (
//                      ''
//                  )}
//                  <ul className="ps-dropdown-menu">
//                      <li>
//                          <a
//                              href="/"
//                              onClick={e =>
//                                  this.handleChangeCurrency(e, {
//                                      symbol: '$',
//                                      text: 'USD',
//                                  })
//                              }>
//                              USD
//                          </a>
//                      </li>
//                      <li>
//                          <a
//                              href="/"
//                              onClick={e =>
//                                  this.handleChangeCurrency(e, {
//                                      symbol: '€',
//                                      text: 'EURO',
//                                  })
//                              }>
//                              EURO
//                          </a>
//                      </li>
//                      <li>
//                          <a
//                              href="/"
//                              onClick={e =>
//                                  this.handleChangeCurrency(e, {
//                                      symbol: '£',
//                                      text: 'GBP',
//                                  })
//                              }>
//                             GBP
//                         </a>
//                      </li>
//                 </ul>
//              </div>
//         );
//     }
// }
// const mapStateToProps = state => {
//     return state.setting;
//};
//export default connect(mapStateToProps)(CurrencyDropdown);
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CurrencyDropdown);


/***/ }),

/***/ 5124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var _components_shared_headers_modules_MiniCart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7898);
/* harmony import */ var _components_shared_headers_modules_AccountQuickLinks__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6500);






const HeaderActions = ({ ecomerce , auth  })=>{
    const { compareItems , wishlistItems  } = ecomerce;
    // views
    let headerAuthView;
    if (auth.isLoggedIn && Boolean(auth.isLoggedIn) === true) {
        headerAuthView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_headers_modules_AccountQuickLinks__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            isLoggedIn: true
        });
    } else {
        headerAuthView = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_headers_modules_AccountQuickLinks__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            isLoggedIn: false
        });
    }
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "header__actions",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                href: "/account/compare",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                    className: "header__extra",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                            className: "icon-chart-bars"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                children: compareItems ? compareItems.length : 0
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_3__["default"], {
                href: "/account/wishlist",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                    className: "header__extra",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                            className: "icon-heart"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                                children: wishlistItems ? wishlistItems.length : 0
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_headers_modules_MiniCart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            headerAuthView
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,react_redux__WEBPACK_IMPORTED_MODULE_2__.connect)((state)=>state
)(HeaderActions));


/***/ }),

/***/ 8538:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);




// class LanguageSwicher extends Component {
//     constructor(props) {
//         super(props);
//     }
//     handleFeatureWillUpdate(e) {
//         e.preventDefault();
//         notification.open({
//             message: 'Opp! Something went wrong.',
//             description: 'This feature has been updated later!',
//             duration: 500,
//         });
//     }
//     render() {
//         return (
//             <div className="ps-dropdown language">
//                 <a href="#" onClick={this.handleFeatureWillUpdate.bind(this)}>
//                     <img src="/static/img/flag/en.png" alt="martfury" />
//                     English
//                 </a>
//                 <ul className="ps-dropdown-menu">
//                     <li>
//                         <a
//                             href="#"
//                             onClick={this.handleFeatureWillUpdate.bind(this)}>
//                             <img src="/static/img/flag/germany.png" alt="martfury" />
//                             Germany
//                         </a>
//                     </li>
//                     <li>
//                         <a
//                             href="#"
//                             onClick={this.handleFeatureWillUpdate.bind(this)}>
//                             <img src="/static/img/flag/fr.png" alt="martfury" />
//                             France
//                         </a>
//                     </li>
//                 </ul>
//             </div>
//         );
//     }
// }
function LanguageSwicher() {
    const { 0: languages , 1: setlanguage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(async ()=>{
        const result = await axios__WEBPACK_IMPORTED_MODULE_2___default()('https://ipapi.co/languages/');
        setlanguage(result.data);
    });
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
        children: languages
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LanguageSwicher);


/***/ }),

/***/ 7898:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modules_MiniCart)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./hooks/useProduct.js
var useProduct = __webpack_require__(6922);
;// CONCATENATED MODULE: ./components/elements/products/ProductOnCart.jsx




const ProductOnCart = ({ product , children  })=>{
    const { thumbnailImage , title  } = (0,useProduct/* default */.Z)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "ps-product--cart-mobile",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "ps-product__thumbnail",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                    href: "/product/[pid]",
                    as: `/product/${product.id}`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                        children: thumbnailImage(product)
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "ps-product__content",
                children: [
                    title(product),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("p", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("small", {
                            children: [
                                "$",
                                product.price,
                                " x ",
                                product.quantity
                            ]
                        })
                    }),
                    ' ',
                    children
                ]
            })
        ]
    }));
};
/* harmony default export */ const products_ProductOnCart = (ProductOnCart);

// EXTERNAL MODULE: ./hooks/useEcomerce.js
var useEcomerce = __webpack_require__(1440);
// EXTERNAL MODULE: ./utilities/ecomerce-helpers.js
var ecomerce_helpers = __webpack_require__(5245);
;// CONCATENATED MODULE: ./components/shared/headers/modules/MiniCart.jsx







const MiniCart = ({ ecomerce  })=>{
    const { products , removeItem , removeItems , getProducts  } = (0,useEcomerce/* default */.Z)();
    function handleRemoveItem(e, productId) {
        e.preventDefault();
        removeItem({
            id: productId
        }, ecomerce.cartItems, 'cart');
    }
    (0,external_react_.useEffect)(()=>{
        getProducts(ecomerce.cartItems, 'cart');
    }, [
        ecomerce
    ]);
    let cartItemsView;
    if (products && products.length > 0) {
        const amount = (0,ecomerce_helpers/* calculateAmount */.fu)(products);
        const productItems = products.map((item)=>{
            return(/*#__PURE__*/ (0,jsx_runtime_.jsx)(products_ProductOnCart, {
                product: item,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                    className: "ps-product__remove",
                    onClick: (e)=>handleRemoveItem(e)
                    ,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-cross"
                    })
                })
            }, item.id));
        });
        cartItemsView = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "ps-cart__content",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "ps-cart__items",
                    children: productItems
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "ps-cart__footer",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                            children: [
                                "Sub Total:",
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("strong", {
                                    children: [
                                        "$",
                                        amount ? amount : 0
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("figure", {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                                    href: "/account/shopping-cart",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                                        className: "ps-btn",
                                        children: "View Cart"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                                    href: "/account/checkout",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                                        className: "ps-btn",
                                        children: "Checkout"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    } else {
        cartItemsView = /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
            className: "ps-cart__content",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "ps-cart__items",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                    children: "No products in cart"
                })
            })
        });
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "ps-cart--mini",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                className: "header__extra",
                href: "#",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                        className: "icon-bag2"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                            children: products ? products.length : 0
                        })
                    })
                ]
            }),
            cartItemsView
        ]
    }));
};
/* harmony default export */ const modules_MiniCart = ((0,external_react_redux_.connect)((state)=>state
)(MiniCart));


/***/ }),

/***/ 9128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ modules_SearchHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: external "antd"
var external_antd_ = __webpack_require__(5725);
// EXTERNAL MODULE: ./repositories/ProductRepository.js
var ProductRepository = __webpack_require__(3328);
// EXTERNAL MODULE: ./components/elements/Rating.jsx
var Rating = __webpack_require__(7660);
// EXTERNAL MODULE: ./hooks/useProduct.js
var useProduct = __webpack_require__(6922);
;// CONCATENATED MODULE: ./components/elements/products/ProductSearchResult.jsx





const ProductSearchResult = ({ product  })=>{
    const { thumbnailImage , price , title  } = (0,useProduct/* default */.Z)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "ps-product ps-product--wide ps-product--search-result",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "ps-product__thumbnail",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                    href: "/product/[pid]",
                    as: `/product/${product.id}`,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                        children: thumbnailImage(product)
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "ps-product__content",
                children: [
                    title(product),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ps-product__rating",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)(Rating/* default */.Z, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                                children: product.ratingCount
                            })
                        ]
                    }),
                    price(product)
                ]
            })
        ]
    }));
};
/* harmony default export */ const products_ProductSearchResult = (ProductSearchResult);

;// CONCATENATED MODULE: ./components/shared/headers/modules/SearchHeader.jsx







const exampleCategories = [
    'All',
    'Babies & Moms',
    'Books & Office',
    'Cars & Motocycles',
    'Clothing & Apparel',
    '\xa0Accessories',
    'Bags',
    'Kid’s Fashion',
    'Mens',
    'Shoes',
    'Sunglasses',
    'Womens',
    'Computers & Technologies',
    'Desktop PC',
    'Laptop',
    'Smartphones',
    'Consumer Electrics',
    'Air Conditioners',
    'Accessories',
    'Type Hanging Cell',
    'Audios & Theaters',
    'Headphone',
    'Home Theater System',
    'Speakers',
    'Car Electronics',
    'Audio & Video',
    'Car Security',
    'Radar Detector',
    'Vehicle GPS',
    'Office Electronics',
    'Printers',
    'Projectors',
    'Scanners',
    'Store & Business',
    'Refrigerators',
    'TV Televisions',
    '4K Ultra HD TVs',
    'LED TVs',
    'OLED TVs',
    'Washing Machines',
    'Type Drying Clothes',
    'Type Horizontal',
    'Type Vertical',
    'Garden & Kitchen',
    'Cookware',
    'Decoration',
    'Furniture',
    'Garden Tools',
    'Home Improvement',
    'Powers And Hand Tools',
    'Utensil & Gadget',
    'Health & Beauty',
    'Equipments',
    'Hair Care',
    'Perfumer',
    'Wine Cabinets', 
];
function useDebounce(value, delay) {
    const { 0: debouncedValue , 1: setDebouncedValue  } = (0,external_react_.useState)(value);
    (0,external_react_.useEffect)(()=>{
        // Update debounced value after delay
        const handler = setTimeout(()=>{
            setDebouncedValue(value);
        }, delay);
        return ()=>{
            clearTimeout(handler);
        };
    }, [
        value,
        delay
    ]);
    return debouncedValue;
}
const SearchHeader = ()=>{
    const inputEl = (0,external_react_.useRef)(null);
    const { 0: isSearch , 1: setIsSearch  } = (0,external_react_.useState)(false);
    const { 0: keyword , 1: setKeyword  } = (0,external_react_.useState)('');
    const { 0: resultItems , 1: setResultItems  } = (0,external_react_.useState)(null);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const debouncedSearchTerm = useDebounce(keyword, 300);
    function handleClearKeyword() {
        setKeyword('');
        setIsSearch(false);
        setLoading(false);
    }
    function handleSubmit(e) {
        e.preventDefault();
        router_default().push(`/search?keyword=${keyword}`);
    }
    (0,external_react_.useEffect)(()=>{
        if (debouncedSearchTerm) {
            setLoading(true);
            if (keyword) {
                const queries = {
                    _limit: 5,
                    title_contains: keyword
                };
                const products = ProductRepository/* default.getRecords */.Z.getRecords(queries);
                products.then((result)=>{
                    setLoading(false);
                    setResultItems(result);
                    setIsSearch(true);
                });
            } else {
                setIsSearch(false);
                setKeyword('');
            }
            if (loading) {
                setIsSearch(false);
            }
        } else {
            setLoading(false);
            setIsSearch(false);
        }
    }, [
        debouncedSearchTerm
    ]);
    // Views
    let productItemsView, clearTextView, selectOptionView, loadingView, loadMoreView;
    if (!loading) {
        if (resultItems && resultItems.length > 0) {
            if (resultItems.length > 5) {
                loadMoreView = /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                    className: "ps-panel__footer text-center",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(next_link["default"], {
                        href: "/search",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("a", {
                            children: "See all results"
                        })
                    })
                });
            }
            productItemsView = resultItems.map((product)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)(products_ProductSearchResult, {
                    product: product
                }, product.id)
            );
        } else {
            productItemsView = /*#__PURE__*/ (0,jsx_runtime_.jsx)("p", {
                children: "No product found."
            });
        }
        if (keyword !== '') {
            clearTextView = /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
                className: "ps-form__action",
                onClick: handleClearKeyword,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("i", {
                    className: "icon icon-cross2"
                })
            });
        }
    } else {
        loadingView = /*#__PURE__*/ (0,jsx_runtime_.jsx)("span", {
            className: "ps-form__action",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsx)(external_antd_.Spin, {
                size: "small"
            })
        });
    }
    selectOptionView = exampleCategories.map((option)=>/*#__PURE__*/ (0,jsx_runtime_.jsx)("option", {
            value: option,
            children: option
        }, option)
    );
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        className: "ps-form--quick-search",
        method: "get",
        action: "/",
        onSubmit: handleSubmit,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                className: "ps-form__categories",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsx)("select", {
                    className: "form-control",
                    children: selectOptionView
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "ps-form__input",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("input", {
                        ref: inputEl,
                        className: "form-control",
                        type: "text",
                        value: keyword,
                        placeholder: "I'm shopping for...",
                        onChange: (e)=>setKeyword(e.target.value)
                    }),
                    clearTextView,
                    loadingView
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsx)("button", {
                onClick: handleSubmit,
                children: "Search"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: `ps-panel--search-result${isSearch ? ' active ' : ''}`,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsx)("div", {
                        className: "ps-panel__content",
                        children: productItemsView
                    }),
                    loadMoreView
                ]
            })
        ]
    }));
};
/* harmony default export */ const modules_SearchHeader = (SearchHeader);


/***/ }),

/***/ 9913:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_static_data_menu_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8398);
/* harmony import */ var _components_elements_menu_Menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2222);




const MenuCategoriesDropdown = ()=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "menu--product-categories",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "menu__toggle",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("i", {
                        className: "icon-menu"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("span", {
                        children: "Shop by Department"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                className: "menu__content",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_elements_menu_Menu__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    source: _public_static_data_menu_json__WEBPACK_IMPORTED_MODULE_2__/* .product_categories */ .a,
                    className: "menu--dropdown"
                })
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuCategoriesDropdown);


/***/ }),

/***/ 6418:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _elements_menu_Menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2222);
/* harmony import */ var _public_static_data_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8398);
/* harmony import */ var _headers_modules_CurrencyDropdown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7834);
/* harmony import */ var _headers_modules_LanguageSwicher__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8538);
/* harmony import */ var _components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9913);









class NavigationDefault extends react__WEBPACK_IMPORTED_MODULE_1__.Component {
    constructor(props){
        super(props);
    }
    handleFeatureWillUpdate(e) {
        e.preventDefault();
        antd__WEBPACK_IMPORTED_MODULE_3__.notification.open({
            message: 'Opp! Something went wrong.',
            description: 'This feature has been updated later!',
            duration: 500
        });
    }
    render() {
        return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("nav", {
            className: "navigation",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "ps-container",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", {
                        className: "navigation__left",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_components_shared_menus_MenuCategoriesDropdown__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "navigation__right",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_elements_menu_Menu__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                source: _public_static_data_menu__WEBPACK_IMPORTED_MODULE_5__/* .menuPrimary.menu_1 */ .A.u,
                                className: "menu"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "navigation__extra",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                            href: "/vendor/become-a-vendor",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                children: "Sell on Martfury"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                            href: "/account/order-tracking",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("a", {
                                                children: "Tract your order"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_headers_modules_CurrencyDropdown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("li", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_headers_modules_LanguageSwicher__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        }));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavigationDefault);


/***/ })

};
;