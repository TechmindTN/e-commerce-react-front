"use strict";
exports.id = 8578;
exports.ids = [8578];
exports.modules = {

/***/ 8707:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_FooterWidgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4188);
/* harmony import */ var _modules_FooterLinks__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2324);
/* harmony import */ var _modules_FooterCopyright__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3305);





const FooterDefault = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("footer", {
        className: "ps-footer",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_modules_FooterWidgets__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_modules_FooterLinks__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_modules_FooterCopyright__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            ]
        })
    })
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterDefault);


/***/ }),

/***/ 7528:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Repository__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8833);

class PostRepository {
    constructor(callback){
        this.callback = callback;
    }
    async getPosts(payload) {
        const endPoint = `posts?${(0,_Repository__WEBPACK_IMPORTED_MODULE_0__/* .serializeQuery */ .Y$)(payload)}`;
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .basePostUrl */ .$Y}/${endPoint}`).then((response)=>{
            if (response.data.length > 0) {
                return response.data;
            } else {
                return null;
            }
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getPostBySlug(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .basePostUrl */ .$Y}/posts?slug=${payload}`).then((response)=>{
            if (response.data.length > 0) {
                return response.data[0];
            } else {
                return null;
            }
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getPostsByCollectionSlug(payload) {
        const endPoint = `collections?${(0,_Repository__WEBPACK_IMPORTED_MODULE_0__/* .serializeQuery */ .Y$)(payload)}`;
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .basePostUrl */ .$Y}/${endPoint}`).then((response)=>{
            if (response.data && response.data[0].posts.length > 0) {
                return response.data[0].posts;
            } else {
                return null;
            }
        }).catch((error)=>{
            console.log(JSON.stringify(error));
            return null;
        });
        return reponse;
    }
    async getPostItemsByKeyword(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .basePostUrl */ .$Y}/posts?title_contains=${payload}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
    async getPostItemsByCategory(payload) {
        const reponse = await _Repository__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .ZP.get(`${_Repository__WEBPACK_IMPORTED_MODULE_0__/* .basePostUrl */ .$Y}/posts?title_contains=${payload}`).then((response)=>{
            return response.data;
        }).catch((error)=>({
                error: JSON.stringify(error)
            })
        );
        return reponse;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new PostRepository());


/***/ })

};
;